package com.example.ticketcalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.ticketcalculator.R.id.calcular

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.androidmanifest)

        // Referencias a los elementos en el layout
        val etPremioNombre: EditText = findViewById(R.id.etPremioNombre)
        val imageView: ImageView = findViewById(R.id.imageView)
        val etCantidadPiezas: EditText = findViewById(R.id.etCantidadPiezas)
        val etCostoPesos: EditText = findViewById(R.id.etCostoPesos)
        val btnCalcular: Button = findViewById(R.id.calcular)
        val tvResultado: TextView = findViewById(R.id.tvResultado)

        // Evento de clic en el botón
        btnCalcular.setOnClickListener {
            val nombrePremio = etPremioNombre.text.toString()
            val cantidadPiezas = etCantidadPiezas.text.toString().toIntOrNull()
            val costoPesos = etCostoPesos.text.toString().toDoubleOrNull()

            if (cantidadPiezas != null && costoPesos != null) {
                val tickets = calcularTickets(cantidadPiezas, costoPesos)
                tvResultado.text = "Nombre del Premio: $nombrePremio\nNúmero de Tickets: $tickets"
            } else {
                tvResultado.text = "Por favor, ingrese valores válidos"
            }
        }
    }

    // Función para calcular el número de tickets
    private fun calcularTickets(cantidad: Int, costo: Double): Int {
        // Lógica de cálculo de tickets (esto puede variar según tus requisitos)
        // Por ejemplo, supongamos que cada pieza requiere 10 tickets y el costo en pesos es irrelevante
        return cantidad * 10
    }
}